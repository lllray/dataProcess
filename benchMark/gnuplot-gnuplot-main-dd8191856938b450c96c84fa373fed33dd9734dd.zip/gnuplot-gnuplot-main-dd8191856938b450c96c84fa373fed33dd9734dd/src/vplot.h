/*
 * prototypes for external callers
 */
void vplot_points (struct surface_points *plot, double level);
void vplot_isosurface (struct surface_points *plot, int downsample);
