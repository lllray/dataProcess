/* GNUPLOT - stats.h */

#ifndef GNUPLOT_STAT_H
# define GNUPLOT_STAT_H

#include "syscfg.h"

void statsrequest(void);

#endif /* GNUPLOT_STAT_H */
