#ifdef HAVE_LIBCERF
void f_cerf(union argument *z);
void f_cdawson(union argument *z);
void f_faddeeva(union argument *z);
void f_voigtp(union argument *z);
void f_voigt(union argument *z);
void f_erfi(union argument *z);
#endif
